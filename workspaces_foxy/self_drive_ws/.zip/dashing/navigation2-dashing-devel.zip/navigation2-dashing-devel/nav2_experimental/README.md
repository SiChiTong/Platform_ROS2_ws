# Nav2 Experimental

This is a set of packages that are being developed using experimental technologies for use in robot navigation. 

These packages, like all others, come with no warranty except these packages _can be particularly dangerous_ and should be read, understood, and sufficiently tested before deploying in production or on actual robot hardware.  

The hope is that these package(s) will become full-fledged packages in the Navigation2 metapackage, but for now they're very experimental and it is recommended to be used only in simulation. 
