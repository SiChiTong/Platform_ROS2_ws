# Empty Room

20x20 meter empty room.
